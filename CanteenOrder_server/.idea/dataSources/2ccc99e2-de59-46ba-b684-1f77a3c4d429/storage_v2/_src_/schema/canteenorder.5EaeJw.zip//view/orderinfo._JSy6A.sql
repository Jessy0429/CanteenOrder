create view orderinfo as
select `o`.`orderID`                                               AS `orderID`,
       `canteenorder`.`user`.`username`                            AS `username`,
       `d`.`consignee`                                             AS `consignee`,
       `d`.`address`                                               AS `address`,
       `o`.`dishware`                                              AS `dishware`,
       `o`.`storeID`                                               AS `storeID`,
       `o`.`d_time`                                                AS `d_time`,
       concat(`canteenorder`.`dish`.`dishname`, `od`.`dishnumber`) AS `dish`
from ((((`canteenorder`.`order` `o` join `canteenorder`.`deliveredinfo` `d`) join `canteenorder`.`user`) join `canteenorder`.`order_dish` `od`)
         join `canteenorder`.`dish`
              on (((`o`.`orderID` = `od`.`orderID`) and (`o`.`userID` = `canteenorder`.`user`.`userID`) and
                   (`o`.`deliveredID` = `d`.`deliveredID`) and (`od`.`dishID` = `canteenorder`.`dish`.`dishID`))))
group by `o`.`orderID`;

