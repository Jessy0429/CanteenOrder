create definer = root@localhost trigger Delstore
    before delete
    on store
    for each row
begin
delete from Dish
where storeID = old.storeID;
end;

