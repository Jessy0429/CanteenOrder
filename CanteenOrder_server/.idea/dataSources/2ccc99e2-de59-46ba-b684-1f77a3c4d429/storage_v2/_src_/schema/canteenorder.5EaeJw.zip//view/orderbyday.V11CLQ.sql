create view orderbyday as
select cast(`o`.`o_time` as date) AS `date`,
       `s`.`storename`            AS `storename`,
       `c`.`canteenname`          AS `canteenname`,
       count(`o`.`orderID`)       AS `sum_order`
from ((`canteenorder`.`store` `s` join `canteenorder`.`canteen` `c`)
         join `canteenorder`.`order` `o` on (((`s`.`canteenID` = `c`.`canteenID`) and (`o`.`storeID` = `s`.`storeID`))))
group by `s`.`storeID`;

